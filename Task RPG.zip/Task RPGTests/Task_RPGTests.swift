//
//  Task_RPGTests.swift
//  Task RPGTests
//
//  Created by Terence Lau on 3/6/19.
//  Copyright © 2019 Terence Lau. All rights reserved.
//

import XCTest
@testable import Task_RPG

class Task_RPGTests: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
