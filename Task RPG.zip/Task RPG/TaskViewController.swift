import UIKit

class TaskViewController: UIViewController {
    
    var name: String = "Name Transfered?"
    var exp: Int = 0
    var level: Int = 0
    var curve: [Int] = [0, 100, 300, 600, 1000, 1500, 2100, 2800, 3600, 4500]
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var levelLabel: UILabel!
    @IBOutlet weak var expLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLabel.text = name
        updateStats()
    }
    
    func updateStats() {
        level = 0;
        if exp > 4500 {
            exp = 4500
        }
        for point in curve {
            if exp >= point {
                level += 1
            }
        }
        
        levelLabel.text = "Level \(String(level))"
        
        if exp == 4500 {
            expLabel.text = "EXP: \(String(exp))/4500"
        }
        else {
            expLabel.text = "EXP: \(String(exp))/\(String(curve[level]))"
        }
        
    }
    
    
    @IBAction func GainEXPButton(_ sender: Any) {
        exp += 50
        updateStats()
    }
    
}
