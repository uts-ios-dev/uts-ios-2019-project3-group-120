import UIKit

class TaskViewController: UIViewController {
    
    var name: String = "Name Transfered?"
    
    @IBOutlet weak var nameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameLabel.text = name
    }
}
